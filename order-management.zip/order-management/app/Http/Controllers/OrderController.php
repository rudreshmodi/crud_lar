<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\User;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class OrderController extends Controller
{
    public function __construct()
    {
        // Check if the user is authenticated and has an 'admin' role
        if (!Auth::check() || Auth::user()->role != 'admin') {
            // Redirect back with an error if not an authenticated admin
            return redirect()->back()->with('error', 'You do not have the necessary permissions to access this page.');
        }
    }

    
    public function index()
    {
    
        $orders = Order::with('user')->paginate(10);
        return view('orders.index', compact('orders'));
    }

    
 public function create()
{
    
    $users = User::where('role', 'user')->get();
    return view('orders.create', compact('users'));
}


    
    public function store(Request $request)
    {
        
        $validated = $request->validate([
            'user_id' => 'required|exists:users,id',
            'products' => 'required|array|min:1',
            'products.*.name' => 'required|string|max:255',
            'products.*.qty' => 'required|integer|min:1',
            'products.*.amount' => 'required|numeric|min:0',
        ], [
            'user_id.required' => 'Please select a user for the order.',
            'user_id.exists' => 'The selected user is invalid.',
            'products.required' => 'You must add at least one product to the order.',
            'products.array' => 'The products should be an array.',
            'products.*.name.required' => 'Each product must have a valid name.',
            'products.*.qty.required' => 'Each product must have a valid quantity.',
            'products.*.qty.min' => 'The quantity for each product must be at least 1.',
            'products.*.amount.required' => 'The amount for each product is required.',
            'products.*.amount.numeric' => 'The amount for each product must be a valid number.',
            'products.*.amount.min' => 'The amount for each product must be at least 0.',
        ]);

        
        $order = Order::create([
            'user_id' => $validated['user_id'],
            'total' => 0,
        ]);

        $total = 0;
        
        foreach ($validated['products'] as $productData) {
            $productTotal = $productData['qty'] * $productData['amount'];

            
            Product::create([
                'order_id' => $order->id,
                'name' => $productData['name'],
                'qty' => $productData['qty'],
                'amount' => $productData['amount'],
                'total' => $productTotal,
            ]);

            
            $total += $productTotal;
        }

        
        $order->update(['total' => $total]);

        
        return redirect()->route('orders.index')->with('success', 'Order created successfully!');
    }

    
    public function show($id)
    {
    
        $order = Order::with('products')->findOrFail($id);

    
        $productNames = $order->products->pluck('name')->implode(', ');

    
        return view('orders.show', compact('order', 'productNames'));
    }
}
