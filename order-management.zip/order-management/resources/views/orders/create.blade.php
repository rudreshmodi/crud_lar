@extends('layouts.app')

@section('title', 'Add new Order')

@section('content')
    <div class="container mx-auto px-6 py-8">
        <!-- Flash Messages -->
        @if (session('success'))
            <div class="bg-green-500 text-white p-4 rounded-lg mb-4">
                {{ session('success') }}
            </div>
        @endif
        @if (session('error'))
            <div class="bg-red-500 text-white p-4 rounded-lg mb-4">
                {{ session('error') }}
            </div>
        @endif

        <!-- Breadcrumb -->
        <nav class="text-sm text-gray-600 mb-4">
            <ol class="flex items-center space-x-2">
                <li>
                    <a href="{{ route('dashboard') }}" class="text-blue-600 hover:underline flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-1" viewBox="0 0 20 20" fill="currentColor">
                            <path
                                d="M10.707 1.293a1 1 0 00-1.414 0l-8 8a1 1 0 001.414 1.414L4 9.414V17a1 1 0 001 1h4v-4h2v4h4a1 1 0 001-1V9.414l1.293 1.293a1 1 0 001.414-1.414l-8-8z" />
                        </svg>
                        Home
                    </a>
                </li>
                <li>/</li>
                <li>
                    <a href="{{ route('orders.index') }}" class="text-blue-600 hover:underline">Orders</a>
                </li>
                <li>/</li>
                <li class="text-gray-800">Create Order</li>
            </ol>
        </nav>

        <!-- Create Order Form -->
        <form action="{{ route('orders.store') }}" method="POST"
            class="bg-white p-8 shadow-lg rounded-lg border border-gray-300 space-y-6">
            @csrf

            <!-- User selection -->
            <div class="mb-4">
                <label for="user_id" class="block text-lg font-semibold text-gray-700 mb-2">Select User</label>
                <select name="user_id" id="user_id"
                    class="w-1/2 p-3 border border-gray-300 rounded-lg text-gray-700 focus:ring-2 focus:ring-blue-500">
                    <option value="" selected disabled>Select User</option>
                    @foreach ($users as $user)
                        <option value="{{ $user->id }}" {{ old('user_id') == $user->id ? 'selected' : '' }}>
                            {{ $user->name }}
                        </option>
                    @endforeach
                </select>

                @error('user_id')
                    <div class="text-red-500 text-sm mt-2">{{ $message }}</div>
                @enderror
            </div>

            <!-- Products Table (Default One Product Row) -->
            <div id="products" class="space-y-4">
                <div class="product bg-gray-50 p-4 rounded-lg relative border border-gray-200">
                    <button type="button"
                        class="remove absolute -top-3 -right-3 bg-red-600 text-white py-1 px-3 rounded-full hover:bg-red-700 transition">&times;</button>
                    <div class="mb-4">
                        <input type="text" name="products[0][name]"
                            class="form-control w-full p-3 border border-gray-300 rounded-lg" placeholder="Product Name"
                            value="{{ old('products.0.name') }}">
                        @error('products.0.name')
                            <div class="text-red-500 text-sm mt-2">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-4 flex items-center">
                        <button type="button" class="decrease bg-gray-300 text-gray-700 p-3 rounded-l-lg">-</button>
                        <input type="number" name="products[0][qty]"
                            class="qty w-1/3 p-3 border-t border-b border-gray-300 text-center"
                            value="{{ old('products.0.qty', 1) }}" min="1">
                        @error('products.0.qty')
                            <div class="text-red-500 text-sm mt-2">{{ $message }}</div>
                        @enderror
                        <button type="button" class="increase bg-gray-300 text-gray-700 p-3 rounded-r-lg">+</button>
                    </div>
                    <div class="mb-4">
                        <input type="number" name="products[0][amount]"
                            class="amount form-control w-full p-3 border border-gray-300 rounded-lg" placeholder="Amount"
                            value="{{ old('products.0.amount') }}">
                        @error('products.0.amount')
                            <div class="text-red-500 text-sm mt-2">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="text-right text-lg font-semibold">Total: <span class="total">0</span></div>
                </div>
            </div>

            <div class="flex justify-between items-center mt-4">
                <div class="text-lg font-semibold">Grand Total: <span id="grandTotal">0</span></div>
                <button type="button" id="addProduct"
                    class="bg-blue-500 text-white py-3 px-6 rounded-lg shadow-md hover:bg-blue-600 transition">
                    <i class="fa-solid fa-plus"></i> Add Product
                </button>
            </div>

            <div class="flex justify-end mt-6">
                <a href="{{ route('orders.index') }}"
                    class="bg-gray-500 text-white py-3 px-8 rounded-lg hover:bg-gray-600 transition mr-4">Cancel</a>
                <button type="submit"
                    class="bg-green-600 text-white py-3 px-8 rounded-lg hover:bg-green-700 transition">Create Order</button>
            </div>
        </form>
    </div>

    <script>
        function updateGrandTotal() {
            let totalElements = document.querySelectorAll('.total');
            let grandTotal = Array.from(totalElements).reduce((sum, el) => sum + parseFloat(el.textContent || 0), 0);
            document.getElementById('grandTotal').textContent = grandTotal.toFixed(2);
        }

        document.getElementById('addProduct').addEventListener('click', function() {
            let productIndex = document.querySelectorAll('.product').length;
            let newProduct = document.createElement('div');
            newProduct.classList.add('product', 'bg-gray-50', 'p-4', 'rounded-lg', 'relative', 'border',
                'border-gray-200');

            newProduct.innerHTML = `
            <button type="button" class="remove absolute -top-3 -right-3 bg-red-600 text-white py-1 px-3 rounded-full hover:bg-red-700 transition">&times;</button>
            <div class="mb-4">
                <input type="text" name="products[${productIndex}][name]" class="form-control w-full p-3 border border-gray-300 rounded-lg" placeholder="Product Name">
            </div>
            <div class="mb-4 flex items-center">
                <button type="button" class="decrease bg-gray-300 text-gray-700 p-3 rounded-l-lg">-</button>
                <input type="number" name="products[${productIndex}][qty]" class="qty w-1/3 p-3 border-t border-b border-gray-300 text-center" value="1" min="1">
                <button type="button" class="increase bg-gray-300 text-gray-700 p-3 rounded-r-lg">+</button>
            </div>
            <div class="mb-4">
                <input type="number" name="products[${productIndex}][amount]" class="amount form-control w-full p-3 border border-gray-300 rounded-lg" placeholder="Amount">
            </div>
            <div class="text-right text-lg font-semibold">Total: <span class="total">0</span></div>
        `;

            document.getElementById('products').appendChild(newProduct);
            updateGrandTotal();
        });

        document.getElementById('products').addEventListener('click', function(event) {
            let productDiv = event.target.closest('.product');

            if (event.target.classList.contains('increase')) {
                let qtyInput = productDiv.querySelector('.qty');
                qtyInput.value = parseInt(qtyInput.value) + 1;
                updateTotal(productDiv);
            }

            if (event.target.classList.contains('decrease')) {
                let qtyInput = productDiv.querySelector('.qty');
                if (qtyInput.value > 1) {
                    qtyInput.value = parseInt(qtyInput.value) - 1;
                    updateTotal(productDiv);
                }
            }

            if (event.target.classList.contains('remove')) {
                event.target.parentElement.remove();
                updateGrandTotal();
            }
        });

        document.getElementById('products').addEventListener('input', function(event) {
            if (event.target.classList.contains('qty') || event.target.classList.contains('amount')) {
                let productDiv = event.target.closest('.product');
                updateTotal(productDiv);
            }
        });

        function updateTotal(productDiv) {
            let qty = parseInt(productDiv.querySelector('.qty').value) || 0;
            let amount = parseFloat(productDiv.querySelector('.amount').value) || 0;
            let total = qty * amount;
            productDiv.querySelector('.total').textContent = total.toFixed(2);
            updateGrandTotal();
        }

        updateGrandTotal();
    </script>
@endsection
