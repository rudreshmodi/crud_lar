@extends('layouts.app')

@section('title', 'Order Details')

@section('content')
    <div class="container mx-auto px-6">

        <!-- Order Details Card -->
        <div class="bg-white p-6 rounded-xl shadow-lg border border-gray-200 mb-3">
            <h2 class="text-2xl font-semibold text-gray-800 mb-4">Order ID: <span
                    class="text-indigo-600">{{ $order->id }}</span></h2>
            <p class="text-lg text-gray-700"><strong>User:</strong> <span
                    class="text-gray-800">{{ $order->user->name }}</span></p>
            <p class="text-lg text-gray-700"><strong>Total:</strong> <span class="text-green-600 font-semibold">₹
                    {{ $order->total ?? 'N/A' }}</span></p>
            <p class="text-lg text-gray-700"><strong>Created At:</strong> <span
                    class="text-gray-600">{{ $order->created_at->format('Y-m-d H:i') }}</span></p>
        </div>

        <!-- Products Grid View -->
        <div class="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
            <h3 class="text-xl font-semibold text-gray-800 mb-6">Products:</h3>
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                @foreach ($order->products as $product)
                    <div
                        class="bg-white p-6 rounded-lg shadow-md border border-gray-200 hover:shadow-lg transition duration-300 ease-in-out transform hover:scale-105">
                        <h4 class="text-lg font-semibold text-gray-800 mb-2">{{ $product->name }}</h4>
                        <p class="text-gray-600"><strong>Quantity:</strong> {{ $product->qty }}</p>
                        <p class="text-gray-600"><strong>Amount:</strong> ₹ {{ $product->amount }}</p>
                        <p class="text-gray-600"><strong>Total:</strong> ₹ {{ $product->total }}</p>
                    </div>
                @endforeach
            </div>
        </div>

    </div>
@endsection
