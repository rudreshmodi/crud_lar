<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon; // Import Carbon for date/time handling

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Insert users with specific data
        DB::table('users')->insert([
            [
                'name' => 'John Doe',
                'email' => 'john.doe@example.com',
                'role' => 'admin',
                'email_verified_at' => null,
                'password' => Hash::make ('Test@123'), // Hashed password
                'remember_token' => null,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
            ],
            [
                'name' => 'Jane Smith',
                'email' => 'jane.smith@example.com',
                'role' => 'user',
                'email_verified_at' => null,
                'password' => Hash::make ('Test@123'),
                'remember_token' => null,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
            ],
            [
                'name' => 'Mike Johnson',
                'email' => 'mike.johnson@example.com',
                'role' => 'user',
                'email_verified_at' => null,
                'password' => Hash::make ('Test@123'),
                'remember_token' => null,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
            ],
            [
                'name' => 'Emily Davis',
                'email' => 'emily.davis@example.com',
                'role' => 'user',
                'email_verified_at' => null,
                'password' => Hash::make ('Test@123'),
                'remember_token' => null,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
            ],
            [
                'name' => 'David Brown',
                'email' => 'david.brown@example.com',
                'role' => 'user',
                'email_verified_at' => null,
                'password' => Hash::make ('Test@123'),
                'remember_token' => null,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
            ],
            [
                'name' => 'Sarah Lee',
                'email' => 'sarah.lee@example.com',
                'role' => 'user',
                'email_verified_at' => null,
                'password' => Hash::make ('Test@123'),
                'remember_token' => null,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
            ]
        ]);
    }
}
