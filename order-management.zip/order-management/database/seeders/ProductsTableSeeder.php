<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Faker\Factory as Faker;

class ProductsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create();
        $orders = DB::table('orders')->pluck('id'); 
        
        foreach ($orders as $orderId) {
            foreach (range(1, 4) as $index) {
                DB::table('products')->insert([
                    'order_id' => $orderId, 
                    'name' => $faker->word(),
                    'qty' => $faker->numberBetween(1, 10),
                    'amount' => $faker->randomFloat(2, 5, 100),
                    'total' => $faker->randomFloat(2, 5, 1000),
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }
        }
    }
}
