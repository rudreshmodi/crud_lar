

<?php $__env->startSection('title', 'Add new Order'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto px-6 py-8">
        <!-- Flash Messages -->
        <?php if(session('success')): ?>
            <div class="bg-green-500 text-white p-4 rounded-lg mb-4">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="bg-red-500 text-white p-4 rounded-lg mb-4">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <!-- Breadcrumb -->
        <nav class="text-sm text-gray-600 mb-4">
            <ol class="flex items-center space-x-2">
                <li>
                    <a href="<?php echo e(route('dashboard')); ?>" class="text-blue-600 hover:underline flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-1" viewBox="0 0 20 20" fill="currentColor">
                            <path
                                d="M10.707 1.293a1 1 0 00-1.414 0l-8 8a1 1 0 001.414 1.414L4 9.414V17a1 1 0 001 1h4v-4h2v4h4a1 1 0 001-1V9.414l1.293 1.293a1 1 0 001.414-1.414l-8-8z" />
                        </svg>
                        Home
                    </a>
                </li>
                <li>/</li>
                <li>
                    <a href="<?php echo e(route('orders.index')); ?>" class="text-blue-600 hover:underline">Orders</a>
                </li>
                <li>/</li>
                <li class="text-gray-800">Create Order</li>
            </ol>
        </nav>

        <!-- Create Order Form -->
        <form action="<?php echo e(route('orders.store')); ?>" method="POST"
            class="bg-white p-8 shadow-lg rounded-lg border border-gray-300 space-y-6">
            <?php echo csrf_field(); ?>

            <!-- User selection -->
            <div class="mb-4">
                <label for="user_id" class="block text-lg font-semibold text-gray-700 mb-2">Select User</label>
                <select name="user_id" id="user_id"
                    class="w-1/2 p-3 border border-gray-300 rounded-lg text-gray-700 focus:ring-2 focus:ring-blue-500">
                    <option value="" selected disabled>Select User</option>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($user->id); ?>" <?php echo e(old('user_id') == $user->id ? 'selected' : ''); ?>>
                            <?php echo e($user->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-red-500 text-sm mt-2"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Products Table (Default One Product Row) -->
            <div id="products" class="space-y-4">
                <div class="product bg-gray-50 p-4 rounded-lg relative border border-gray-200">
                    <button type="button"
                        class="remove absolute -top-3 -right-3 bg-red-600 text-white py-1 px-3 rounded-full hover:bg-red-700 transition">&times;</button>
                    <div class="mb-4">
                        <input type="text" name="products[0][name]"
                            class="form-control w-full p-3 border border-gray-300 rounded-lg" placeholder="Product Name"
                            value="<?php echo e(old('products.0.name')); ?>">
                        <?php $__errorArgs = ['products.0.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500 text-sm mt-2"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-4 flex items-center">
                        <button type="button" class="decrease bg-gray-300 text-gray-700 p-3 rounded-l-lg">-</button>
                        <input type="number" name="products[0][qty]"
                            class="qty w-1/3 p-3 border-t border-b border-gray-300 text-center"
                            value="<?php echo e(old('products.0.qty', 1)); ?>" min="1">
                        <?php $__errorArgs = ['products.0.qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500 text-sm mt-2"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <button type="button" class="increase bg-gray-300 text-gray-700 p-3 rounded-r-lg">+</button>
                    </div>
                    <div class="mb-4">
                        <input type="number" name="products[0][amount]"
                            class="amount form-control w-full p-3 border border-gray-300 rounded-lg" placeholder="Amount"
                            value="<?php echo e(old('products.0.amount')); ?>">
                        <?php $__errorArgs = ['products.0.amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500 text-sm mt-2"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="text-right text-lg font-semibold">Total: <span class="total">0</span></div>
                </div>
            </div>

            <div class="flex justify-between items-center mt-4">
                <div class="text-lg font-semibold">Grand Total: <span id="grandTotal">0</span></div>
                <button type="button" id="addProduct"
                    class="bg-blue-500 text-white py-3 px-6 rounded-lg shadow-md hover:bg-blue-600 transition">
                    <i class="fa-solid fa-plus"></i> Add Product
                </button>
            </div>

            <div class="flex justify-end mt-6">
                <a href="<?php echo e(route('orders.index')); ?>"
                    class="bg-gray-500 text-white py-3 px-8 rounded-lg hover:bg-gray-600 transition mr-4">Cancel</a>
                <button type="submit"
                    class="bg-green-600 text-white py-3 px-8 rounded-lg hover:bg-green-700 transition">Create Order</button>
            </div>
        </form>
    </div>

    <script>
        function updateGrandTotal() {
            let totalElements = document.querySelectorAll('.total');
            let grandTotal = Array.from(totalElements).reduce((sum, el) => sum + parseFloat(el.textContent || 0), 0);
            document.getElementById('grandTotal').textContent = grandTotal.toFixed(2);
        }

        document.getElementById('addProduct').addEventListener('click', function() {
            let productIndex = document.querySelectorAll('.product').length;
            let newProduct = document.createElement('div');
            newProduct.classList.add('product', 'bg-gray-50', 'p-4', 'rounded-lg', 'relative', 'border',
                'border-gray-200');

            newProduct.innerHTML = `
            <button type="button" class="remove absolute -top-3 -right-3 bg-red-600 text-white py-1 px-3 rounded-full hover:bg-red-700 transition">&times;</button>
            <div class="mb-4">
                <input type="text" name="products[${productIndex}][name]" class="form-control w-full p-3 border border-gray-300 rounded-lg" placeholder="Product Name">
            </div>
            <div class="mb-4 flex items-center">
                <button type="button" class="decrease bg-gray-300 text-gray-700 p-3 rounded-l-lg">-</button>
                <input type="number" name="products[${productIndex}][qty]" class="qty w-1/3 p-3 border-t border-b border-gray-300 text-center" value="1" min="1">
                <button type="button" class="increase bg-gray-300 text-gray-700 p-3 rounded-r-lg">+</button>
            </div>
            <div class="mb-4">
                <input type="number" name="products[${productIndex}][amount]" class="amount form-control w-full p-3 border border-gray-300 rounded-lg" placeholder="Amount">
            </div>
            <div class="text-right text-lg font-semibold">Total: <span class="total">0</span></div>
        `;

            document.getElementById('products').appendChild(newProduct);
            updateGrandTotal();
        });

        document.getElementById('products').addEventListener('click', function(event) {
            let productDiv = event.target.closest('.product');

            if (event.target.classList.contains('increase')) {
                let qtyInput = productDiv.querySelector('.qty');
                qtyInput.value = parseInt(qtyInput.value) + 1;
                updateTotal(productDiv);
            }

            if (event.target.classList.contains('decrease')) {
                let qtyInput = productDiv.querySelector('.qty');
                if (qtyInput.value > 1) {
                    qtyInput.value = parseInt(qtyInput.value) - 1;
                    updateTotal(productDiv);
                }
            }

            if (event.target.classList.contains('remove')) {
                event.target.parentElement.remove();
                updateGrandTotal();
            }
        });

        document.getElementById('products').addEventListener('input', function(event) {
            if (event.target.classList.contains('qty') || event.target.classList.contains('amount')) {
                let productDiv = event.target.closest('.product');
                updateTotal(productDiv);
            }
        });

        function updateTotal(productDiv) {
            let qty = parseInt(productDiv.querySelector('.qty').value) || 0;
            let amount = parseFloat(productDiv.querySelector('.amount').value) || 0;
            let total = qty * amount;
            productDiv.querySelector('.total').textContent = total.toFixed(2);
            updateGrandTotal();
        }

        updateGrandTotal();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Rudresh Modi\Documents\order-management\resources\views/orders/create.blade.php ENDPATH**/ ?>