

<?php $__env->startSection('title', 'Order Details'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto px-6">

        <!-- Order Details Card -->
        <div class="bg-white p-6 rounded-xl shadow-lg border border-gray-200 mb-3">
            <h2 class="text-2xl font-semibold text-gray-800 mb-4">Order ID: <span
                    class="text-indigo-600"><?php echo e($order->id); ?></span></h2>
            <p class="text-lg text-gray-700"><strong>User:</strong> <span
                    class="text-gray-800"><?php echo e($order->user->name); ?></span></p>
            <p class="text-lg text-gray-700"><strong>Total:</strong> <span class="text-green-600 font-semibold">₹
                    <?php echo e($order->total ?? 'N/A'); ?></span></p>
            <p class="text-lg text-gray-700"><strong>Created At:</strong> <span
                    class="text-gray-600"><?php echo e($order->created_at->format('Y-m-d H:i')); ?></span></p>
        </div>

        <!-- Products Grid View -->
        <div class="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
            <h3 class="text-xl font-semibold text-gray-800 mb-6">Products:</h3>
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div
                        class="bg-white p-6 rounded-lg shadow-md border border-gray-200 hover:shadow-lg transition duration-300 ease-in-out transform hover:scale-105">
                        <h4 class="text-lg font-semibold text-gray-800 mb-2"><?php echo e($product->name); ?></h4>
                        <p class="text-gray-600"><strong>Quantity:</strong> <?php echo e($product->qty); ?></p>
                        <p class="text-gray-600"><strong>Amount:</strong> ₹ <?php echo e($product->amount); ?></p>
                        <p class="text-gray-600"><strong>Total:</strong> ₹ <?php echo e($product->total); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Rudresh Modi\Documents\order-management\resources\views/orders/show.blade.php ENDPATH**/ ?>