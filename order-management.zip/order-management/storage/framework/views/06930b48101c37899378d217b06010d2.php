

<?php $__env->startSection('title', 'Manage Orders'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">

        <!-- Create Order Button -->
        <div class="text-right mb-2">
            <button onclick="window.location.href='<?php echo e(route('orders.create')); ?>'"
                class="text-white py-3 px-8 rounded-lg shadow-md bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition duration-300 transform hover:scale-105">
                <i class="fas fa-plus mr-2"></i> Create Order
            </button>
        </div>

        <!-- Orders Table -->
        <div class="mt-2 overflow-x-auto bg-white shadow-lg rounded-lg border border-gray-200">
            <table class="min-w-full text-center text-sm text-gray-700">
                <thead class="bg-indigo-100 text-indigo-700">
                    <tr>
                        <th class="px-6 py-4 font-semibold uppercase">Order ID</th>
                        <th class="px-6 py-4 font-semibold uppercase">User Name</th>
                        <th class="px-6 py-4 font-semibold uppercase">Total</th>
                        <th class="px-6 py-4 font-semibold uppercase">Created At</th>
                        <th class="px-6 py-4 font-semibold uppercase">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:bg-gray-50 transition-colors duration-300">
                            <td class="px-6 py-4 font-medium text-gray-900"><?php echo e($order->id); ?></td>
                            <td class="px-6 py-4 text-gray-600"><?php echo e($order->user->name); ?></td>
                            <td class="px-6 py-4 text-gray-600">
                                ₹ <?php echo e(number_format($order->total ?? 0, 2)); ?>

                            </td>
                            <td class="px-6 py-4 text-gray-600"><?php echo e($order->created_at->format('Y-m-d H:i')); ?></td>
                            <td class="px-6 py-4">
                                <a href="<?php echo e(route('orders.show', $order->id)); ?>"
                                    class="inline-flex items-center px-6 py-3 text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-md transition duration-200 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                                    <i class="fas fa-eye mr-2"></i>
                                    <span class="ml-2">View</span>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <div class="mt-6">
            <div class="flex justify-center">
                <?php echo e($orders->links('pagination::tailwind')); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Rudresh Modi\Documents\order-management\resources\views/orders/index.blade.php ENDPATH**/ ?>