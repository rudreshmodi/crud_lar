<?php 

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\OrderController;
use Illuminate\Support\Facades\Auth;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {

    if (Auth::check() && Auth::user()->role === 'admin') {

        return view('dashboard');
    }
    return view('index');
})->middleware(['auth', 'verified'])->name('dashboard');


// Profile routes for authenticated users
Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

// Order routes, ensuring only authenticated admins can access
Route::middleware('auth')->group(function () {
    Route::get('orders', function () {
        // Only allow admins to access this route
        if (Auth::user()->role != 'admin') {
            return redirect()->route('dashboard')->with('error', 'You do not have the necessary permissions to access this page.');
        }
        return app(OrderController::class)->index();
    })->name('orders.index');

    Route::get('orders/create', function () {
        // Only allow admins to access this route
        if (Auth::user()->role != 'admin') {
            return redirect()->route('dashboard')->with('error', 'You do not have the necessary permissions to access this page.');
        }
        return app(OrderController::class)->create();
    })->name('orders.create');

    Route::post('orders', function () {
        // Only allow admins to access this route
        if (Auth::user()->role != 'admin') {
            return redirect()->route('dashboard')->with('error', 'You do not have the necessary permissions to access this page.');
        }
        return app(OrderController::class)->store(request());
    })->name('orders.store');

    Route::get('orders/{order}', function ($order) {
        // Only allow admins to access this route
        if (Auth::user()->role != 'admin') {
            return redirect()->route('dashboard')->with('error', 'You do not have the necessary permissions to access this page.');
        }
        return app(OrderController::class)->show($order);
    })->name('orders.show');
});

require __DIR__.'/auth.php';
